package org.java.variableEx;

public class VarEx03 {

	public static void main(String[] args) {
		
		System.out.println("변수이름 규칙");
	
//		int int; // 키워드 (예약어)를 사용할 수 없다
//		int 1var; // 숫자로 시작하지 않는다
//		int m var; // 공백을 허용하지 않는다
//		int !var; // _ , $ 외의 특수문자 허용하지 않는다
//		int Var; 또는 var // 대소문자를 구분한다
		
		int Var1=10;
		int var1=9;
		
		System.out.println(Var1==var1);
		
//		int var; // 소문자로 시작하자
//		int varNumber; // 다른 문자가 시작되면 대문자로 시작하자
//		int 바; // 한글은 사용하지 말자
		
		
		
		
	}
}

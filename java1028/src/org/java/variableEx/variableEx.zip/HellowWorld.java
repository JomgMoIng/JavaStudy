package org.java.variableEx;

public class HellowWorld {

	//main method
	public static void main(String[] args) {
		System.out.println("Hellow World!!~2");// 명령문 의 끝 > 반드시 ; 를붙여야함
	}
}

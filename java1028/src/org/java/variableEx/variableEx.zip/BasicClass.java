package org.java.variableEx;

public class BasicClass {

	public String userId="m11";
	public String UserPw="1111";
	
	public void basicMethod() {
		System.out.println("아이디 : " + userId);
		System.out.println("비밀번호 : " + UserPw);
	}

}
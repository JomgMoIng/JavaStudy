package org.study.commend;




public interface MemberCommend {
//일
	void excuteQueryCommend();
}
